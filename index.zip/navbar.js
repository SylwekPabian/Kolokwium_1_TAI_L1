let nav = '<h1>Nawigacja</h1>' +
    '<a href="index.html">Index  </a>' +
    '<a href="kontakt.html">Kontakt</a>';

let elem = document.querySelector(".nav-bar");

elem.innerHTML = nav;